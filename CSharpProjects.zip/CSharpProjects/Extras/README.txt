The Tree sample project contains the code of the TreeView program described in Step Four.

The AdventureGame2 project implements a new version of the RoomList class which subclasses and serializes a Dictionary. This is explained in Step 10.