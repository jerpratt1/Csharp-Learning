﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassesAndMore {

    public enum CardSuits {
        Clubs,
        Spades,
        Hearts,
        Diamonds,
        Unknown
    }

    public enum PictureCards {
        Jack = 11,
        Queen = 12,
        King = 13,
        NotAPictureCard = 0
    }

    public enum DaysOfWeek {
        Monday,
        Tuesday,
        Wednesday,
        Thursday,
        Friday,
        Saturday,
        Sunday
    }

}
